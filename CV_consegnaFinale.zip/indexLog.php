<?php
require("connessioneDB.php");
session_start();

if (!isset($_SESSION["utente"])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="immagini/icon.jpeg">
    <link rel="stylesheet" href="style.css">
    <title>ArteAri - Area Riservata</title>
</head>
<body>

<header>
    <div class="header-container">
        <a id="home" href="indexLog.php">
            <div class="logo">
                <img src="immagini/icon.jpeg" alt="Logo">
                <h1>ArteAri</h1>
            </div>
        </a>

        <nav>
            <ul>
                <li><a href="indexLog.php" class="active">HOME</a></li>
                <li><a href="shop.php">SHOP</a></li>
                <li><a href="carrello.php">CARRELLO</a></li>
                <li><a href="account.php">IL MIO ACCOUNT</a></li>
            </ul>
        </nav>

        <div class="auth-section">
            <a href="index.html" class="auth-link">ESCI</a>
        </div>
    </div>
</header>

<main>
    <div id="sfondo"></div>
</main>

<footer>
    <div class="footer-content">
        <p>&copy; 2026 ArteAri - Tutti i diritti riservati</p>
        <div class="footer-links">
            <a href="https://www.instagram.com/arteari_la.casa.del.ricamo/">Contatti</a>
        </div>
    </div>
</footer>
    
</body>
</html>